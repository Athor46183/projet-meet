import React from "react";

const Radio = ({ id, value, onCheck, resultat }) => {
  return (
    <div className="form-check">
      <input
        className="form-check-input"
        type="radio"
        name={`${id}`}
        id="exampleRadios1"
        value={value}
        onClick={() => onCheck(value, id)}
      />
      <label class="form-check-label" for="exampleRadios1"></label>
    </div>
  );
};

export default Radio;
