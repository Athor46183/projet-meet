import React from "react";

const Pagination = ({ onNext, onPrevious, page, resultats, onFinish }) => {
  // const resultat = resultats.find((r) => r.id === page);

  return (
    <div>
      <nav aria-label="Page navigation example">
        <ul className="pagination">
          {/* <li className="page-item">
            <button
              className="page-link"
              onClick={onPrevious}
              disabled={page <= 1 ? true : false}
            >
              Précédent
            </button>
          </li> */}
          {page === 17 ? (
            <li className="page-item">
              <button className="page-link" onClick={onFinish}>
                Terminé
              </button>
            </li>
          ) : (
            <li className="page-item">
              <button className="page-link" onClick={onNext}>
                Suivant
              </button>
            </li>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default Pagination;
