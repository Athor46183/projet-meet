import React from "react";
import Radio from "./radio";

const Table = ({ questions, reponses, page, onChecked, resultats }) => {
  const myquestions = questions.sort((a, b) => {
    return a < b;
  });
  const fmq = myquestions.filter((r) => {
    return r.id === page;
  });
  const myreponses = reponses.sort((a, b) => {
    return a < b;
  });
  const fmr = myreponses.filter((r) => {
    return r.id === page;
  });
  return (
    <table className="table table-bordered table-hover table-sm">
      <thead>
        <tr>
          {fmq.map((q) => (
            <th scope="col" key={q.enonce}>
              {q.enonce},{q.id}
            </th>
          ))}
          <th scope="col">
            {resultats.reduce((somme, resultat) => {
              return (somme += resultat.value);
            }, 0)}
          </th>
        </tr>
      </thead>
      <tbody>
        {fmr.map((r) => (
          <tr key={r.enonce}>
            <td>{r.enonce}</td>
            <td>
              <Radio
                id={r.id}
                value={r.value}
                onCheck={onChecked}
                resultats={resultats}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
