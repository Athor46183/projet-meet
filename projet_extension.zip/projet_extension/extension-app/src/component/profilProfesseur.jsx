import React from "react";
import axios from "axios";
import Form from "./common/form";
class ProfilProfesseur extends Form {
  state = {
    data: {},
    errors: {},
  };
  handleGetSeance = async () => {
    const result = await axios.get("http://localhost:4000/api/seances");
    console.log(result);
  };
  render() {
    return (
      <div className="container">
        <div class="row">
          <div class="col">
            {
              (this.renderInput("idSeance", "ID seance"),
              this.renderInput(""),
              this.renderInput())
            }
            <button
              type="button"
              className="btn btn-primary"
              onClick={this.handleGetSeance}
              style={{ marginRight: 15 }}
            >
              Enregistrez une nouvelle réunion
            </button>
          </div>
          <div className="col">
            <div class="container">
              <div class="row">
                <div class="col">
                  {this.renderSelect(
                    "choix de la classe",
                    "Choix de la classe",
                    [
                      { id: 1, name: "LGLSIA" },
                      { id: 2, name: "LGLSIB" },
                    ]
                  )}
                </div>
                <div class="col">
                  <form>
                    <div className="col-sm-10 offset-sm-2">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="gridCheck1"
                        />
                        <label className="form-check-label" for="gridCheck1">
                          Example checkbox
                        </label>
                      </div>
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="gridCheck1"
                        />
                        <label className="form-check-label" for="gridCheck1">
                          Example checkbox
                        </label>
                      </div>
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="gridCheck1"
                        />
                        <label className="form-check-label" for="gridCheck1">
                          Example checkbox
                        </label>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProfilProfesseur;
