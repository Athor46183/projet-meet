import React, { Component } from "react";
import { getQuestions } from "../questions";
import { getReponses } from "../reponses";
import Pagination from "./common/pagination";
import Table from "./common/table";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
class EvaluationCour extends Component {
  state = {
    resultats: [
      { id: 1, value: 0 },
      { id: 2, value: 0 },
      { id: 3, value: 0 },
      { id: 4, value: 0 },
      { id: 5, value: 0 },
      { id: 6, value: 0 },
      { id: 7, value: 0 },
      { id: 8, value: 0 },
      { id: 9, value: 0 },
      { id: 10, value: 0 },
      { id: 11, value: 0 },
      { id: 12, value: 0 },
      { id: 13, value: 0 },
      { id: 14, value: 0 },
      { id: 15, value: 0 },
      { id: 16, value: 0 },
      { id: 17, value: 0 },
    ],
    questions: [],
    reponses: [],
    page: 1,
  };
  componentDidMount() {
    this.setState({ questions: getQuestions() });
    this.setState({ reponses: getReponses() });
  }
  handleNext = () => {
    const resultat = this.state.resultats.find((r) => r.id === this.state.page);
    if (resultat.value === 0) {
      toast.error(
        "vous ne pouvez pas passez à la question suivante sans avoir répondu à celle ci"
      );
    } else {
      this.setState({ page: this.state.page + 1 });
    }
  };
  handlePrevious = () => {
    this.setState({ page: this.state.page - 1 });
  };
  handleCkeck = (value, id) => {
    const result = this.state.resultats.find((r) => r.id === id);
    // console.log(this.state.resultats);
    let index = this.state.resultats.indexOf(result);
    const resultats = [...this.state.resultats];
    result.value = value;
    resultats[index] = result;
    this.setState({ resultats });
  };
  handleFinish = () => {
    const resultat = this.state.resultats.find((r) => r.id === this.state.page);
    if (resultat.value === 0) {
      toast.error(
        "vous ne pouvez pas passez à la question suivante sans avoir répondu à celle ci"
      );
    } else {
      const score = this.state.resultats.reduce((somme, resultat) => {
        return (somme += resultat.value);
      }, 0);
      console.log(score);
    }
  };
  render() {
    return (
      <div>
        <ToastContainer />
        <p>Evaluation du cours</p>
        <div className="container">
          <Table
            questions={this.state.questions}
            reponses={this.state.reponses}
            page={this.state.page}
            resultats={this.state.resultats}
            onChecked={this.handleCkeck}
          />
          <Pagination
            page={this.state.page}
            onNext={this.handleNext}
            onPrevious={this.handlePrevious}
            onFinish={this.handleFinish}
            resultats={this.state.resultats}
          />
        </div>
      </div>
    );
  }
}

export default EvaluationCour;
