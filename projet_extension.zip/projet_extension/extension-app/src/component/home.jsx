import React, { Component } from "react";
class Home extends Component {
  state = {};
  render() {
    return (
      <div>
        <h1>Extention app</h1>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            this.props.history.push("/evaluation");
          }}
        >
          Evaluer la réunion
        </button>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            this.props.history.push("/evaluation");
          }}
        ></button>
      </div>
    );
  }
}

export default Home;
