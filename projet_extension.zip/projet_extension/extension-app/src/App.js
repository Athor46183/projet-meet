// import logo from "./logo.svg";
import "./App.css";
import { Route, Switch, Redirect } from "react-router-dom";
import EvaluationCour from "./component/evaluationCour";
import Home from "./component/home";
import NotFound from "./component/notFound";
import LoginForm from "./component/loginForm";
import ProfilProfesseur from "./component/profilProfesseur";

function App() {
  return (
    <div className="App">
      <div className="content">
        <Switch>
          <Route path="/profil-professeur" component={ProfilProfesseur} />
          <Route path="/home" component={Home} />
          <Route path="/loginform" component={LoginForm} />
          <Route path="/evaluation" component={EvaluationCour} />
          <Route path="/not-found" component={NotFound} />
          <Route path="/" exact component={LoginForm} />
          <Redirect to="/not-found" />
        </Switch>
      </div>
    </div>
  );
}
export default App;
