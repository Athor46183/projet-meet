export const questions = [
  {
    enonce:
      "Comment qualifier vous la charge de travail demandée par le cours ?",
    id: 1,
  },
  { enonce: "Le cours à t'il répondu à vos attente ?", id: 2 },
  {
    enonce: "Le cours à t'il contribué à votre connaissance de la matiére ?",
    id: 3,
  },
  { enonce: "Comment califier vous le cours ?", id: 4 },
  { enonce: "que pensez vous du rythme du cours ?", id: 5 },
  {
    enonce:
      "Pensez vous que les supports utilisé(support papier,présentation) durant le cours ont été utiles ?",
    id: 6,
  },
  {
    enonce:
      "Quel est la probabilité que vous recommandiez le cours à d'autre étudiant ?",
    id: 7,
  },
  {
    enonce: "Dans l'ensemble, êtes vous satisfait(e) du contenu du cours ?",
    id: 8,
  },
  {
    enonce:
      "Dans l'ensemble, quel est votre degré de satisfraction consernant le cours ?",
    id: 9,
  },
  {
    enonce:
      "Quel était le niveau de qualité global de l'instructeur pour ce cours ?",
    id: 10,
  },
  { enonce: "Le cours était-il bien organisé ?", id: 11 },
  {
    enonce:
      "Quel était le niveau de connaissances du sujet de cours de l'instructeur ?",
    id: 12,
  },
  { enonce: "les explication de l'instructeur était-elles claires ?", id: 13 },
  {
    enonce:
      "De quelle maniére l'instructeur était-il conserné par l'apprentissage des éléves dans ce cours ?",
    id: 14,
  },
  {
    enonce:
      "L'instructeur avait-il une attitude encourangeante envers les élèves ?",
    id: 15,
  },
  {
    enonce: "L'instructeur était-il disponible en dehors du cours  ?",
    id: 16,
  },
  {
    enonce:
      "Dans quel mesure les critéres d'évaluations du cours étaient-ils clairs ?",
    id: 17,
  },
];

export function getQuestions() {
  return questions;
}
