const fs = require("fs");
const readline = require("readline");
const { google } = require("googleapis");
const mysql = require("mysql");
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "meet",
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("mysql connected");
});
// If modifying these scopes, delete token.json.
const SCOPES = ["https://www.googleapis.com/auth/admin.reports.audit.readonly"];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = "token.json";

// Load client secrets from a local file.
fs.readFile("credentials.json", (err, content) => {
  if (err) return console.error("Error loading client secret file", err);

  // Authorize a client with the loaded credentials, then call the
  // Reports API.
  authorize(JSON.parse(content), listLoginEvents);
});

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 *
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize(credentials, callback) {
  const { client_secret, client_id, redirect_uris } = credentials.web;
  const oauth2Client = new google.auth.OAuth2(
    client_id,
    client_secret,
    redirect_uris[0]
  );

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getNewToken(oauth2Client, callback);
    oauth2Client.credentials = JSON.parse(token);
    callback(oauth2Client);
  });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 *
 * @param {google.auth.OAuth2} oauth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback to call with the authorized
 *     client.
 */
function getNewToken(oauth2Client, callback) {
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: SCOPES,
  });
  console.log("Authorize this app by visiting this url:", authUrl);
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  rl.question("Enter the code from that page here: ", (code) => {
    rl.close();
    oauth2Client.getToken(code, (err, token) => {
      if (err) return console.error("Error retrieving access token", err);
      oauth2Client.credentials = token;
      storeToken(token);
      callback(oauth2Client);
    });
  });
}

/**
 * Store token to disk be used in later program executions.
 *
 * @param {Object} token The token to store to disk.
 */
function storeToken(token) {
  fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
    if (err) return console.warn(`Token not stored to ${TOKEN_PATH}`, err);
    console.log(`Token stored to ${TOKEN_PATH}`);
  });
}

/**
 * Lists the last 10 login events for the domain.
 *
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
function dateDebut(dat, temps) {
  var truc = dat.toString();
  var t = truc.split("T");
  var time1 = t[1].split(":");
  var hh = parseInt(time1[0]);
  var mm = parseInt(time1[1]);
  var splitss = time1[2].split(".");
  var ss = parseInt(splitss[0]);
  var temp = parseInt(temps);
  var totalss = hh * 3600 + mm * 60 + ss + temp;
  hh = parseInt(totalss / 3600);
  totalss = totalss % 3600;
  mm = parseInt(totalss / 60);
  ss = totalss % 60;
  var datedebut = new Array();
  var heuredebut = new Array();
  heuredebut[0] = hh.toString();
  heuredebut[1] = mm.toString();
  heuredebut[2] = ss.toString();
  var hdb = heuredebut.join(":");
  datedebut[0] = t[0];
  datedebut[1] = hdb;
  var final = datedebut.join("-");
  return final;
}

function traiteDate(date) {
  var t = date.split("T");
  var z = t[1].split(".");
  t[1] = z[0];

  var final = t.join(" ");
  return final;
}

let seance = new Array();
let participant = new Array();
function listLoginEvents(auth) {
  const service = google.admin({ version: "reports_v1", auth });
  service.activities.list(
    {
      userKey: "all",
      applicationName: "meet",
      eventName: "call_ended",
      //   maxResults: 10,
      // filters: "meeting_code==vzqzwaabny",
    },
    (err, res) => {
      if (err) return console.error("The API returned an error:", err.message);
      const activities = res.data.items;
      if (activities.length) {
        // console.log("Logins:");

        // console.log("InfoMeet:");

        for (i = 0; i < activities.length; i++) {
          var activity = activities[i];
          var conferenceid;
          var partageecran;
          var partageecran2;
          var dureepresence;
          var typeterm;
          var email;
          var region;
          var orgEmail;
          var datedebut;
          var datefin;
          var partecran;
          var nbdeco = 0;
          var presencemoy;
          var endpointid;
          var traitedate;
          var codeMeet;
          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "endpoint_id") {
              endpointid = parametre.value;
              break;
            }
          }
          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "meeting_code") {
              codeMeet = parametre.value;
              break;
            }
          }

          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "conference_id") {
              conferenceid = parametre.value;
              break;
            }
          }
          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "screencast_send_seconds") {
              partageecran = parametre.intValue;
              break;
            }
          }

          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "screencast_recv_seconds") {
              partageecran2 = parametre.intValue;
              if (partageecran === "0" || partageecran2 === "0") {
                partecran = "non";
              } else {
                partecran = "oui";
              }
              break;
            }
          }

          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "duration_seconds") {
              dureepresence = parametre.intValue;

              break;
            }
          }
          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "device_type") {
              typeterm = parametre.value;
              break;
            }
          }

          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "organizer_email") {
              orgEmail = parametre.value;
              break;
            }
          }

          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name === "identifier") {
              email = parametre.value;

              if (email == orgEmail) {
                datefin = activity.id.time;
              }
              break;
            }
          }
          for (j = 0; j < activity.events[0].parameters.length; j++) {
            var parametre = activity.events[0].parameters[j];
            if (parametre.name == "location_region") {
              region = parametre.value;
              break;
            }
          }

          for (k = 0; k < activities.length; k++) {
            var activity2 = activities[k];
            var durepresence;
            var idendpoint;

            for (m = 0; m < activity2.events[0].parameters.length; m++) {
              var parametre = activity2.events[0].parameters[m];
              if (parametre.name === "endpoint_id") {
                idendpoint = parametre.value;
                break;
              }
            }

            for (m = 0; m < activity2.events[0].parameters.length; m++) {
              var parametre = activity2.events[0].parameters[m];
              if (parametre.name === "duration_seconds") {
                durepresence = parametre.intValue;
                break;
              }
            }

            for (l = 0; l < activity2.events[0].parameters.length; l++) {
              var parametre = activity2.events[0].parameters[l];
              if (parametre.name === "identifier") {
                var identificateur = parametre.value;
                if (identificateur == orgEmail) {
                  datedebut = dateDebut(datefin, durepresence);
                }
                if (identificateur == email) {
                  nbdeco += 1;
                  if (idendpoint != endpointid) {
                    dureepresence =
                      parseInt(dureepresence) + parseInt(durepresence);
                  }
                }
              }
            }
          }
          presencemoy = parseInt(dureepresence) / nbdeco;

          // console.log("- id conference : " + conferenceid);
          // console.log("- Temps de partage de son ecran : " + partageecran);
          // console.log("- Temps de partage ecran des autres : " + partageecran2);
          // console.log("- durree de presence : " + dureepresence);
          // console.log("- type de terminal utilisee : " + typeterm);
          // console.log("- email : " + email);
          // console.log("- region de connexion : " + region);
          // console.log("- temps de fin de session : " + datefin);
          // console.log("- date de debut: " + datedebut);
          // console.log("- organiser email : " + orgEmail);
          // console.log("- partage ecran :" + partecran);
          // console.log("- nobre de deco/reco :" + nbdeco);
          // console.log("duree presence moyenne" + presencemoy);
          // console.log("");

          traitedate = traiteDate(datefin);
          seance[i] = new Array();
          seance[i][0] = conferenceid;
          seance[i][1] = datedebut;
          seance[i][2] = traitedate;
          seance[i][3] = partecran;
          seance[i][4] = codeMeet;
          if (orgEmail != email) {
            participant[i] = new Array();
            participant[i][0] = nbdeco;
            participant[i][1] = presencemoy;
            participant[i][2] = typeterm;
            participant[i][3] = email;
            participant[i][4] = region;
            participant[i][5] = codeMeet;
          }
        }
      } else {
        console.log("No logins found.");
      }
      // console.table(seance);
      // console.table(participant);
    }
  );
}

const express = require("express");
const app = express();
app.use(express.json());

//////////////////////////////////
app.get("/api/seances", (req, res) => {
  let sql = "select * from seance";
  db.query(sql, (err, result) => {
    if (err) {
      console.log("la requéte ne marche pas ");
      throw errr;
    }
    res.header("Access-Control-Allow-Origin", "*"),
      res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
      ),
      res.status(200).send(result);
  });
});
let mySeance;
let myParticipant;
app.post("/api/seances/", (req, res) => {
  mySeance = seance.filter((s) => s[4] === req.body.codeMeet);
  let sql = `insert into seance values("${mySeance[0]}","${mySeance[1]}","${mySeance[2]}","${mySeance[3]}")`;
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.status(200).send(result);
  });
});
/////////////////////////////
app.post("/api/participants", (req, res) => {
  myParticipant = participant.filter((p) => p[5] === mySeance[4]);
  for (var i = 1; i < participant.length; i++) {
    let sql = `insert into participant(nbDeCo_Ddeco,dureeMoyPre,typeTerm,email,region,confid,note) values ("${
      myParticipant[i][0]
    }","${myParticipant[i][1]}","${myParticipant[i][2]}","${
      myParticipant[i][3]
    }","${myParticipant[i][4]}","${mySeance[4]}",${0})`;
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      console.log("record inserted successfully");
    });
  }

  res.send("record inserted successfully");
  // console.log(participant[0][0]);
});
app.get("/api/participants", (req, res) => {
  let sql = "select * from participant";
  db.query(sql, (err, result) => {
    if (err) {
      console.log("la requéte ne marche pas ");
      throw errr;
    }
    res.header("Access-Control-Allow-Origin", "*"),
      res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
      ),
      res.status(200).send(result);
  });
});
const port = 4000;
app.listen(port, () => console.log(`Listening on port ${port}...`));
// module.exports.seance = seance;
// module.exports.participant = this.participant;
