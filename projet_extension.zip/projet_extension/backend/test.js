// activities.forEach((activity) => {
//   console.log(
//     `${activity.id.time}: ${activity.actor.email} (${activity.events[0].name})`
//   );
//   console.log(activity.events[0]);
////////////////////////////////////////////////////////////////
// let events = activity.events[0];
// let seances = [];
// let seance={};
// let participants=[];
// let participant=[];
// let
// for (let index = 0; index < events.parameters.length; index++) {
//   if (events.parameters[index].name == "conference_id") {

//     seance.id_seance = events.parameters[index].value;
//     participants.id_seance=events.parameters[index].value;
//   }
//   if (events.parameters[index].name == "calendar_event_id"){
//     seances.date = events.parameters[index].value;
//   }
//   if(events.parameters[index].name=="video_send_seconds"){
//     seance.partageEcran=events.parameters[index].value;
//   }

//   if(events.parameters[0].name="endpoint_id"){
//     participant.idConnection=events.parameters[index].value;
//   }
//   if(events.parameters[0].name="endpoint_id"){
//     participant.idConnection=events.parameters[index].value;
//   }
//   if(events.parameters[0].name="endpoint_id"){
//     participant.idConnection=events.parameters[index].value;
//   }
//   if(events.parameters[0].name="endpoint_id"){
//     participant.idConnection=events.parameters[index].value;
//   }
// }
// });
